'use strict';

const express = require('express');
const mysql = require('mysql2/promise');
const { SecretsManagerClient, GetSecretValueCommand } = require('@aws-sdk/client-secrets-manager');
const jwt = require('jsonwebtoken');
const serverless = require('serverless-http');
const { v4: uuidv4 } = require('uuid');
const axios = require('axios');

const app = express();
app.use(express.json());

// Secrets and config management
const secretsManager = new SecretsManagerClient({ region: 'eu-west-1' });
let dbConfig = null;
let jwtSecret = null;

async function getConfig() {
  if (!dbConfig || !jwtSecret) {
    const [dbSecrets, authSecrets] = await Promise.all([
      secretsManager.send(new GetSecretValueCommand({ SecretId: 'minibus-app-db-config' })),
      secretsManager.send(new GetSecretValueCommand({ SecretId: 'minibus-app-jwt-secret' }))
    ]);
    
    dbConfig = JSON.parse(dbSecrets.SecretString);
    jwtSecret = JSON.parse(authSecrets.SecretString).secret;
  }
  return { dbConfig, jwtSecret };
}

// Helper function to send SMS notifications
async function sendSmsNotification(phone, message) {
  try {
    await axios.post(`${process.env.NOTIFICATION_SERVICE_URL}/notify/sms`, {
      to: phone,
      message
    });
  } catch (error) {
    console.error('Error sending SMS notification:', error);
  }
}

// Helper function to get admin phone numbers
async function getAdminPhones(connection) {
  const [admins] = await connection.query(
    'SELECT phone FROM users WHERE role = "admin"'
  );
  return admins.map(admin => admin.phone);
}

// Auth middleware
async function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token necesar' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const { jwtSecret } = await getConfig();
    const decoded = jwt.verify(token, jwtSecret);
    
    // Get user details including role
    const { dbConfig } = await getConfig();
    const connection = await mysql.createConnection(dbConfig);
    
    try {
      const [users] = await connection.query(
        'SELECT id, name, phone, role FROM users WHERE phone = ?',
        [decoded.phone]
      );

      if (users.length === 0) {
        return res.status(404).json({ error: 'Utilizator negăsit' });
      }

      req.user = users[0];
      next();
    } finally {
      await connection.end();
    }
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({ error: 'Token invalid sau expirat' });
  }
}

// Admin middleware
async function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Acces interzis. Necesită rol de administrator.' });
  }
  next();
}

// CORS middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', process.env.CORS_ORIGIN || 'http://localhost:5173');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.header('Access-Control-Allow-Credentials', 'true');
  
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Routes
app.get('/issues', authenticate, async (req, res) => {
  let connection;
  try {
    const { dbConfig } = await getConfig();
    connection = await mysql.createConnection(dbConfig);
    
    const [issues] = await connection.query(
      `SELECT i.*, u.name as reporter_name, u.phone as reporter_phone
       FROM vehicle_issues i 
       JOIN users u ON i.reported_by = u.id 
       ORDER BY i.created_at DESC`
    );
    
    res.json(issues);
  } catch (error) {
    console.error('Error fetching issues:', error);
    res.status(500).json({ error: 'Nu s-au putut încărca problemele' });
  } finally {
    if (connection) await connection.end();
  }
});

app.post('/issues', authenticate, async (req, res) => {
  const { title, description, severity, location } = req.body;
  const { id: userId, name: userName, phone: userPhone } = req.user;

  if (!title || !description || !severity || !location) {
    return res.status(400).json({ error: 'Toate câmpurile sunt obligatorii' });
  }

  let connection;
  try {
    const { dbConfig } = await getConfig();
    connection = await mysql.createConnection(dbConfig);
    
    const issueId = uuidv4();
    await connection.query(
      `INSERT INTO vehicle_issues (id, reported_by, title, description, severity, location) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [issueId, userId, title, description, severity, location]
    );

    // Notify admins
    const adminPhones = await getAdminPhones(connection);
    const notificationMessage = `${userName} a raportat o problemă nouă: ${title}. Severitate: ${severity}`;
    
    for (const adminPhone of adminPhones) {
      await sendSmsNotification(adminPhone, notificationMessage);
    }

    res.status(201).json({ 
      message: 'Problema a fost raportată cu succes',
      id: issueId
    });
  } catch (error) {
    console.error('Error creating issue:', error);
    res.status(500).json({ error: 'Nu s-a putut raporta problema' });
  } finally {
    if (connection) await connection.end();
  }
});

app.patch('/issues/:id', authenticate, requireAdmin, async (req, res) => {
  const { id } = req.params;
  const { status, resolution_notes } = req.body;
  const { id: adminId } = req.user;

  let connection;
  try {
    const { dbConfig } = await getConfig();
    connection = await mysql.createConnection(dbConfig);
    
    // Get issue and reporter details
    const [issues] = await connection.query(
      `SELECT i.*, u.phone as reporter_phone 
       FROM vehicle_issues i 
       JOIN users u ON i.reported_by = u.id 
       WHERE i.id = ?`,
      [id]
    );

    if (issues.length === 0) {
      return res.status(404).json({ error: 'Problema nu a fost găsită' });
    }

    const issue = issues[0];
    const oldStatus = issue.status;

    // Update status
    const updates = {
      status,
      resolved_at: status === 'resolved' ? new Date() : null,
      resolved_by: status === 'resolved' ? adminId : null,
      resolution_notes: resolution_notes || null
    };

    await connection.query(
      `UPDATE vehicle_issues 
       SET status = ?, resolved_at = ?, resolved_by = ?, resolution_notes = ? 
       WHERE id = ?`,
      [updates.status, updates.resolved_at, updates.resolved_by, updates.resolution_notes, id]
    );

    // Notify reporter if status changed
    if (status !== oldStatus) {
      const statusText = status === 'in_progress' ? 'în lucru' : 
                        status === 'resolved' ? 'rezolvată' : status;
      
      const notificationMessage = `Problema "${issue.title}" a fost marcată ca ${statusText}` + 
                                (resolution_notes ? `. Notă: ${resolution_notes}` : '');
      
      await sendSmsNotification(issue.reporter_phone, notificationMessage);
    }

    res.json({ message: 'Status actualizat cu succes' });
  } catch (error) {
    console.error('Error updating issue:', error);
    res.status(500).json({ error: 'Nu s-a putut actualiza statusul' });
  } finally {
    if (connection) await connection.end();
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ 
    error: 'Eroare internă de server',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Lambda handler
exports.handler = serverless(app);
